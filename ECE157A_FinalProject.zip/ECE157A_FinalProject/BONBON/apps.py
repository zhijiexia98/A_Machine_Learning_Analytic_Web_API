from django.apps import AppConfig


class BonbonConfig(AppConfig):
    name = 'BONBON'
